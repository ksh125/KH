package com.sh.test.nested.loop;

import java.util.Scanner;

/**
 * <pre>
 * 
 * 정수하나 입력받아, 그 수가 양수일때만 입력된 수를 줄 수로 적용하여 다음과 같이 출력되게 하는 프로그램을 만들어보자.
 * 
 * 출력예) 
 * 정수 입력 : 5
 * 0   *
 * 1   **
 * 2   ***
 * 3   ****
 * 4   *****
 * 5    ****	1
 * 6     ***	2
 * 7      **	3
 * 8       *	4
 * 
 * </pre>
 */
public class Test3 {

	public static void main(String[] args) {
		Test3 t = new Test3();
//		t.test();
		t.test2();
	}
	public void test2() {
		Scanner sc = new Scanner(System.in);
		System.out.print("양의정수를 하나 입력하세요 ==> ");
		int num = sc.nextInt();

		if (num < 1) {
			System.out.println("양의정수가 아닙니다.");
			return;
		}

		// 가장긴 행의 인덱스
		int row = num * 2 - 1;
		for(int i = 0; i < row; i++) {
			for(int j = 0; j < num; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}

	public void test() {
		Scanner sc = new Scanner(System.in);
		System.out.print("양의정수를 하나 입력하세요 ==> ");
		int num = sc.nextInt();

		if (num < 1) {
			System.out.println("양의정수가 아닙니다.");
			return;
		}

		int row = num * 2 - 1; // 전체행수
		
		for (int i = 0; i < row; i++) {
			if (i < num) {
				// j <= 1 등호 주의!!
				for (int j = 0; j <= i; j++) {
					System.out.print("*");
				}
			} else {
				int blank = i - (num - 1); // 공백수
				for (int j = 0; j < num; j++) {
					if (j < blank)
						System.out.print(" ");
					else
						System.out.print("*");
				}
			}
			System.out.println();
		}
	}

}
