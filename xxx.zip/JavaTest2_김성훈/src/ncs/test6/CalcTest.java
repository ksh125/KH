package ncs.test6;

import java.util.Scanner;

public class CalcTest {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("첫번째 숫자 입력");
		int a = sc.nextInt();
		System.out.println("두번째 숫자 입력");
		int b = sc.nextInt();
		
		
		
	}

}
