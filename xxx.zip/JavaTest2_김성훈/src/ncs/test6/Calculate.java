package ncs.test6;

public class Calculate {
	
	public void sum(int a, int b) {
		System.out.printf("합 : %i", (a + b));
	}
	
	public void subtract(int a, int b) {
		if(a >= b) {
			System.out.printf("차 : %i", (a - b));
		} else {
			System.out.printf("차 : %i", (b - a));
		}
	}
	
	public void multiply(int a, int b) {
		System.out.printf("곱 : %i", (a * b));
	}
	
	public void divide(int a, int b) {
		if(a >= b) {
			System.out.printf("몫 : %i", (a / b));
		} else {
			System.out.printf("몫 : %i", (b / a));
		}
	}

}
