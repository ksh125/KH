package ncs.test5;

public class TestScore {

	public static void main(String[] args) {

		
		
	}

}
