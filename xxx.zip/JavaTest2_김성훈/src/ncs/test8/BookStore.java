package ncs.test8;

public class BookStore {
	
	public static void main(String[] args) {
		
		
		
	}

}
