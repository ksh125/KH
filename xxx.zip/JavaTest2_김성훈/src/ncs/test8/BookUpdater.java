package ncs.test8;

public class BookUpdater {

}
