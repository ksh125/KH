package ncs.test7;

public class Book {

}
