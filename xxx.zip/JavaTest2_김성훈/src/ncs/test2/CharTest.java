package ncs.test2;

public class CharTest {
	
	public static void main(String[] args) {
	
		
		
	}
}
