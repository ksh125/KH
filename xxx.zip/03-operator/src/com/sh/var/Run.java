package com.sh.var;

public class Run {

	public static void main(String[] args) {
		//종합실습예제1
		VarExample var = new VarExample();
		//var.example();
		
		//종합실습예제2
		//var.example2();
		
		var.example3();
	}
}