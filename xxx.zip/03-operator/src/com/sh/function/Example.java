package com.sh.function;

import java.util.Scanner;

public class Example {
	
	/**
	 * <pre>
	 * 기능제공 클래스
	 * - 패키지 : sh.java.operator.function 
	 * - 클래스명 : Example 
	 * - 메소드 :  public void opSample3() { }
	 * - 내용 : 
	 * 		정수 하나입력 받고 양수면 “양수다”
	 * 		아니면 “양수가 아니다”, 0이면 “0이다＂출력
	 * </pre>
	 */
	public void opSample3() {
		Scanner sc = new Scanner(System.in);
		System.out.print("> 정수를 입력하세요 : ");
		int num = sc.nextInt();

		String result = num > 0 ? "양수다" : (num == 0 ? "0이다" : "음수다.");
		System.out.println(result);
	}

	/**
	 * <pre>
	 * 기능제공 클래스 
	 * - 패키지 : sh.java.operator.function 
	 * - 클래스명 : Example 
	 * - 메소드 :  public void opSample4() {}
	 * - 내용 : 
	 * 		정수 하나입력 받고 짝수면 짝수다 
	 * 		홀수면 홀수다 출력
	 * - 힌트 :  
	 * 		짝수/홀수 구분은 %연산자 이용하면 가능
	 * </pre>
	 */
	public void opSample4() {
		Scanner sc = new Scanner(System.in);
		System.out.print("> 정수를 입력하세요 : ");
		int num = sc.nextInt();

		String result = num % 2 == 0 ? "짝수다" : "홀수다";
		System.out.println(result);

	}

}
