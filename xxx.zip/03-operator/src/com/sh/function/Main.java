package com.sh.function;

public class Main {

	public static void main(String[] args) {
		Example e = new Example();
//		e.opSample3();
		e.opSample4();
	}

}
