package sh.java.cast;

/**
 * 컴퓨터 작동원리 1. literal은 동일한 타입의 변수에만 대입가능하다. 2. 동일한 타입 사이에만 연산이 가능하다. - 타입이 다르다면
 * 암묵적 또는 명시적으로 형변환 후에 연산이 가능하다 3. 동일한 타입간 연산결과 역시 동일한 타입이다
 *
 * 자동(암묵적)형변환 - 형변환 시 데이터 손실이 없는 경우 자동으로 현벼환해 준다
 *
 * 명시적 형변환 - 데이터 손실이 있는 경우, 직접 형변환 처리 해야한다 int n = (int) 123.456; // n에 123이
 * 대입된다
 * 
 */
public class CastingStudy {

	public static void main(String[] argds) {

		CastingStudy study = new CastingStudy();
//		study.test1();
//		study.test2();
//		study.test3();
		study.test4();

	}

	public void test4() {
		System.out.println('A' + 0); // 66 (char + int -> int + int)
		System.out.println('0' + 0); // 0 (int + int)
		System.out.println((char)'x'); // x (char char)
		
		System.out.println(2.0 == 5 / 2); // false (double == int / int)
		System.out.println('C' == 67); // true (char == int -> int == int)
		System.out.println('a' == 'b' - 1); // false('a'(char) == (b - 1) (int)
		System.out.println('a' != 97); // true (char != int)
	}
	
	/**
	 * 자동 형변환 예외 상황
	 * - int(4byte) 하위의 자료형(byte, short, char)은 연산시 모두 int로 변환되어 처리된다
	 * - int값을 char변수에 형변환 없이 대입 가능
	 * 
	 */
	public void test3() {
		byte b1 = 10;
		byte b2 = 20;
		byte b3 = (byte) (b1 + b2); // byte + byte -> int + int -> int
		System.out.println(b3);
		
		char a = 'a';
		char b = 'b';
		System.out.println(a + b);
		
		char A = 65; // (char) 생략해도 잘 작동함
		System.out.println(A);
		
		// char + string -> string
		// char + int -> int
		System.out.println('a' + "bcdefu");
		System.out.println('a' + 10000); // 10097
		System.out.println(100 + "a" + "bcd"); // 100abcd
		
	}

	/**
	 * 명시적 형변환
	 */
	public void test2() {
		// 데이터 손실 있음
		double dnum = 123.456;
		int inum = (int) dnum;
		System.out.println(inum);

		// 더 큰 타입으로 명시적 형변환
		int a = 10;
		int b = 4;
		int c = a / b; // a를 b로 나눈 몫만을 처리
		System.out.println(c);

		double d = (double) a / b; // 10.0(double) / 4(int) -> 4.0 -> 2.5
		System.out.println(d);

		// data overflow
		int i = Integer.MAX_VALUE;
		System.out.println(i + 1l);

	}

	/**
	 * 자동 형변환
	 */
	public void test1() {
		byte bnum = 100;
		int n = bnum; // 좌항의 공간에 우항의 값을 대입하라. n공간에 bnum변수의 값을 대입
		System.out.println(n);

		int a = 3;
		double b = 2.5;
		System.out.println(a + b); // 3(int -> double) + 2.5(double)

		char ch = 'a';
		int chnum = ch; // char -> int
		System.out.println(chnum); // 97

		// ascii code table : 문자 -> 숫자 매핑표
		char han = '한';
		int hanNum = han;
		System.out.println(hanNum);

		System.out.println('B' + 100); // char + int -> int + int
	}
}
