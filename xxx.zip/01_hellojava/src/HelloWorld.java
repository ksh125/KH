
public class HelloWorld {
	public static void main(String[] args) {
		System.out.println("Hello World");
		System.out.println("나는 자바 개발자다");
	}
}
