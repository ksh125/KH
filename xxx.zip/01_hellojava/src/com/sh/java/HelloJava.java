package com.sh.java;

import java.util.Date;

import com.sh.java.other.Clock;

public class HelloJava {
	
	/**
	 * 메인메소드
	 * 자바프로그램의 시작/끝
	 * JVM은 main메소드를 찾아 실행
	 * main메소드 안의 명령어를 모두 실행하면 프로그램 종료
	 * 프로그램당 하나의 main 메소드가 존재
	 * 
	 * @param args
	 */
	
	public static void main(String[] args) {
//		객체 래시피 - 클래스를 기반으로 만들어져 메모리에 적재한 형태
//		클래스명 변수명 = new 클래스명()ㅣ
		HelloJava hello = new HelloJava();
		hello.foo();
		System.out.println(12345);
		hello.bar();
		
//		September/today 호출
		September september = new September();
		september.today();
		
//		Clock 호촐
//		다른 패키지의 클래스를 사용하는 경우, import문을 반드시 작성해야 한다
		Clock clock = new Clock();
		clock.now();
		
//		JDK API의 클래스를 가져와 사용하실 수 있습니다
//		ex: Date
		Date date = new Date();
		System.out.println(date);
		
	}
	
	/**
	 * 메소드
	 * 작업 내용
	 * 객체를 통해 호출되어야 한다
	 */
	public void foo() {
		System.out.println(("FOOOOOOOOOOOOOOOOOOO!"));
		
	}

	public void bar() {
		
		System.out.println("Baaaaaaaaaaaaaaaaaaaar!");
		
	}
	
}
