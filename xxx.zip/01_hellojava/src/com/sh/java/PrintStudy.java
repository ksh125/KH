package com.sh.java;

public class PrintStudy {
	
	public static void main(String[] args) {
		PrintStudy study = new PrintStudy();
			study.testPrint();
	}
	
	/**
	 * System.out.println 내용 출력 후 줄바꿈
	 * System.out.print 내용 출력 후 줄바꿈 없음
	 */
	public void testPrint() {
		System.out.println("ㅋ");
		System.out.println("ㅋ");
		System.out.println("ㅋ");
		/**
		 * \n 개행
		 * \t 탭
		 * \" 문자 그대로 쌍따옴표
		 *\\ 문자 그대로 역슬래시
		 */
		
	}

}
