package com.sh.java;

public class September {
	public void today() {
		System.out.println("오늘은 9월 2일!");
		
	}

}
