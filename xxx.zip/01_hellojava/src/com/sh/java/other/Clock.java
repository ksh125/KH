package com.sh.java.other;

public class Clock {
	
	public void now() {
	
		System.out.println("현재 시각은 오후 2시 11분 입니다");
	
	}
	
}
