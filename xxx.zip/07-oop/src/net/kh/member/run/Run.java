package net.kh.member.run;

import net.kh.member.model.Member;

public class Run {

	public static void main(String[] args) {
		Member member = new Member();
		member.setMemberId("honggd");
		member.setMemberPwd("1234");
		member.setMemberName("홍길동");
		member.setGender('남');
		member.setAge(33);
		member.setPhone("01012341234");
		member.setEmail("honggd@naver.com");
		
		System.out.println(member.getMemberId());
		System.out.println(member.getMemberPwd());
		System.out.println(member.getMemberName());
		System.out.println(member.getGender());
		System.out.println(member.getAge());
		System.out.println(member.getPhone());
		System.out.println(member.getEmail());
	}

}
