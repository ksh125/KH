package sh.java.oop.access.modifier._class;

public class AppleRun {

	public static void main(String[] args) {
		Apple apple = new Apple(); // public class 
		PineApple pineApple = new PineApple(); // default class
		Tomato tomato = new Tomato(); // default class
	}

}
