package sh.java.oop.init.block;

public class Run {

	public static void main(String[] args) {
		for(int i = 0; i < 100; i++)
			System.out.println(i);
		
		Sample sample = new Sample();
		System.out.println(sample.num);
		
		System.out.println(Sample.snum);
		
	}

}
