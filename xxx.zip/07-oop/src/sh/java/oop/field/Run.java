package sh.java.oop.field;

public class Run {

	public static void main(String[] args) {
		IPhone14 phone1 = new IPhone14();
		phone1.setOwner("홍길동");
		phone1.setNumber("01012341234");
		System.out.println(phone1.info());
		
		IPhone14 phone2 = new IPhone14();
		String name = "신사임당";
		phone2.setOwner(name);
		phone2.setNumber("01099997777");
		System.out.println(phone2.info());
		
		
		phone1.callTo(phone2); // 홍길동이 신사임당에게 전화를 겁니다.
		
		// @실습문제 : 내 전화기객체 생성
		// 김동현이 홍길동에게 전화를 겁니다.
		// 홍길동이 김동현에게 전화를 겁니다.
		IPhone14 phone3 = new IPhone14();
		phone3.setOwner("김동현");
		phone3.setNumber("01011112222");
		System.out.println(phone3.info());
		
		phone3.callTo(phone1);
		phone1.callTo(phone3);
		
		
		// static변수 사용법
//		IPhone14.WIDTH = 5.7;
//		IPhone14.HEIGHT = 17.3;
		System.out.println("아이폰14의 너비는 " + IPhone14.WIDTH + "cm입니다.");
		System.out.println("아이폰14의 높이는 " + IPhone14.HEIGHT + "cm입니다.");
		
		System.out.println(phone3.WIDTH); // The static field IPhone14.WIDTH should be accessed in a static way
		
	}
	
}
