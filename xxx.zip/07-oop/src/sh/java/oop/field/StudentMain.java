package sh.java.oop.field;

public class StudentMain {

	public static void main(String[] args) {
		KHStudent stdt1 = new KHStudent();
		stdt1.setName("홍길동");
		stdt1.setPhone("01012341234");
		System.out.println(stdt1.info());

		System.out.println();
		
		KHStudent stdt2 = new KHStudent();
		stdt2.setName("신사임당");
		stdt2.setPhone("01055553333");
		System.out.println(stdt2.info());
		
	}

}
