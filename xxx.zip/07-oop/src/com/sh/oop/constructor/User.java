package com.sh.oop.constructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class User {
	
	private String userId;
	private String userPw;
	private String userName;
	private LocalDateTime createdAt;
	
	public User(String string, String string2, String string3, LocalDate localDate) {
		System.out.println("User 생성자가 호출되었습니다");
	}
	
	public User(String userId, String userPw, String userName, LocalDateTime localDate) {
		this.userId = userId;
		this.userPw = userPw;
		this.userName = userName;
		this.createdAt = localDate;
	}
	
	public String userInfo() {
		return "userId = ";
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public String getUserId() {
		return this.userId;
	}
	
	public void setUserPw(String userPw) {
		this.userPw = userPw;
	}
	
	public String getUserPw() {
		return this.userPw;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getUserName() {
		return this.userName;
	}
	
	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
	
	public LocalDateTime getCreatedAt() {
		return this.createdAt;
	}
	
}

