package com.sh.oop.constructor;

import java.time.LocalDate;

public class UserMain {

	public static void main(String[] args) {
//		User us = new User();
		
		User uss = new User("honggd", "1234", "홍길동", LocalDate.now());
		System.out.println(uss.userInfo());
		
	}
	
}
