package com.sh.oop.employee.model.run;

import com.sh.oop.employee.model.vo.Employee;

public class Run {
	
	public static void main(String[] args) {
		Employee st1 = new Employee();
		Employee st2 = new Employee(1, "홍길동", '남', "010-7777-7777");
		Employee st3 = new Employee(0, "유관순", '여', "010-3131-3131","영업부", 30000000, 0.15);
		
		st1.printEmployee();
		st2.printEmployee();
		st3.printEmployee();
		
	}

}
