package com.sh.oop.book.model.vo;

public class Book implements Cloneable{
	
	private String title;		//책제목
	private String author;	//저자
	private int price;			//가격

	public Book() {

	}

	public Book(String title, String author, int price) {
		this.title = title;
		this.author = author;
		this.price = price;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Book [title=" + title + ", author=" + author + ", price=" + price + "]";
	}

	@Override
	public int hashCode() {
//		final int prime = 31;
//		int result = 1;
//		result = prime * result + ((author == null) ? 0 : author.hashCode());
//		result = prime * result + price;
//		result = prime * result + ((title == null) ? 0 : title.hashCode());
//		return result;

		//String 클래스가 제공하는 hashCode()이용하기
		return (author+price+title).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		//두 객체의 주소값을 비교해서 같으면, true 리턴.
		//Object 클래스의 equals메소드가 이와 같다. 
		//return this == obj
		if (this == obj)
			return true;
		
		if (obj == null)
			return false;
		
		//같은 클래스타입이 아니면, false;
		if (getClass() != obj.getClass())
			return false;
		
		//Book객체이므로, 각필드별 비교시작
		Book other = (Book) obj;
		if (author == null) {
			if (other.author != null)
				return false;
		} else if (!author.equals(other.author))
			return false;
		
		if (price != other.price)
			return false;
		
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;

		return true;
	
	}
	
	/**
	 * 복사생성자
	 * @param copy
	 */
	public Book(Book copy){
		this.title = copy.title;
		this.author = copy.author;
		this.price = copy.price;
	}
	/**
	 * 접근제한자, 예외클래스 등을 재정의 할 수 있다.
	 * <p>
	 * super.clone()을 사용하고, 각 필드의 값을 다시 기록할 수 있다.
	 * <p>- super.clone()을 사용하지 않고, new 연산자를 이용한다면, 
	 * - Cloneable인터페이스를 구현할 필요도 없고, ClonenotSupportedException예외처리도 필요없지만, 이는 올바를 clone메소드 이용법이 아니다.
	 * 
	 * <p>
	 * 필드에 다른 객체를 참조하고 있다면, super.clone()은 shallow copy하기 때문에
	 * 필요에 따라 deep copy처리를 해줘야한다.
	 * 
	 * 
	 */
	@Override
	public Book clone() {
		Book b = new Book(this);
		System.out.println("Book 복제 정보 : "+b.toString());
		return b;
	}
	
	/*@Override
	public Book clone() throws CloneNotSupportedException {
		Book b = (Book)super.clone();
		System.out.println("Book 복제 정보 : "+b.toString());
		return b;
	}*/
	
}
