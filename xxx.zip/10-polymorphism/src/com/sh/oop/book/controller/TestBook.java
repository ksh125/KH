package com.sh.oop.book.controller;

import com.sh.oop.book.model.vo.Book;

/**
 * <pre>
 *  => 초기값을 부여한 두 개의 객체를 생성함
 *	=> 두 객체의 정보 출력 처리함  :  toString() 사용
 *	=> 두 객체의 값이 일치하는지 결과 출력 : equals() 사용
 *	=> 첫번째 객체를 복제한 객체 생성함 : clone() 사용
 *	=> 첫번째 객체와 복제 객체의 주소가 같은지 출력
 *	=> 첫번째 객체와 복제 객체의 내용이 같은지 출력
 * </pre>
 *
 */
public class TestBook {

	public static void main(String[] args) {
		Book b1 = new Book("수학의 정석", "나수학", 100);
		Book b2 = new Book("칭찬은 고래도 춤추게한다.", "고래", 300);

		// 두 객체의 정보 출력 처리함 : toString() 사용
		System.out.println("b1=" + b1.toString());
		System.out.println("b2=" + b2.toString());

		// 두 객체의 값이 일치하는지 결과 출력 : equals() 사용
		System.out.println("b1.equals(b2) : " + b1.equals(b2));

		// 복사생성자 이용
		 Book b1Copy = b1.clone();

		// 첫번째 객체와 복제 객체의 주소가 같은지 출력
		System.out.println(b1.hashCode());
		System.out.println(b1Copy.hashCode());

		// 첫번째 객체와 복제 객체의 내용이 같은지 출력
		System.out.println("b1 = " + b1.toString());
		System.out.println("b1Copy = " + b1Copy.toString());
		System.out.println("b1.equals(b1Copy) = " + b1.equals(b1Copy));

		// 타입확인
		System.out.println(b1.getClass()); // class com.oop.book.model.vo.Book
		System.out.println(b1.getClass().getName()); // com.oop.book.model.vo.Book

		// 해쉬코드 override
		System.out.println(b1 == b1Copy); // 주소값비교
		System.out.println(b1.hashCode() == b1Copy.hashCode()); // true
		System.out.println(b1.equals(b1Copy)); // true
	}

}
