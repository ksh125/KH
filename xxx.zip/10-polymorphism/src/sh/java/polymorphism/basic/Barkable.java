package sh.java.polymorphism.basic;

public interface Barkable {
	
	void bark(String sound);
	

}
