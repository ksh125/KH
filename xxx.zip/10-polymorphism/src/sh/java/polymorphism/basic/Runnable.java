package sh.java.polymorphism.basic;

public interface Runnable {
	
	int NUM_OF_LEGS = 4;
	
	void run();

}
