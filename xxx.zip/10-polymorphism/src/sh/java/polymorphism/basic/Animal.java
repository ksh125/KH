package sh.java.polymorphism.basic;

public abstract class Animal {

//	public void say() {
//		System.out.println("저는 동물입니다.");
//	}
	
	public abstract void say();
	
	public abstract void attack();
	
//	public void attack() {
//		System.out.println("애니멀 Attack!!!");
//	}
}
