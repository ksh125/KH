package sh.java.polymorphism.basic;

public class Eagle extends Animal implements Flyable, Barkable {

	@Override
	public void fly(String fly) {
		System.out.println("이글이가 " + fly + "하고 있습니다");
	}
	
	@Override
	public void say() {
		System.out.println("저는 이글입니다.(이글이글)");
	}
	
	@Override
	public void attack() {
		kick();
		peck();
	}
	
	public void kick() {
		System.out.println("이글이는 나약한 발차기따윈 하지 않습니다");
	}
	
	public void peck() {
		System.out.println("대신에 이글이는 강력한 쪼기를 시전합니다");
	}

	@Override
	public void bark(String sound) {
		System.out.println("이글이가 " + sound + " 하며 짖습니다");
	}
	
}
