package sh.java.polymorphism.basic;

import java.util.Random;

/**
 * 다형성
 * - 상속을 이용한 기술로, 자식객체를 부모타입의 참조변수에 담아 제어할 수 있는 기술 
 * 
 *
 */
public class AnimalMain {

	public static void main(String[] args) {
		AnimalMain main = new AnimalMain();
//		main.test1();
//		main.test2();
//		main.test3();
//		main.test4();
//		main.test5();
//		main.test6();
//		main.test7();
		main.test8();
	}
	
	public void test8() {
		Eagle eg = new Eagle();
		eg.say();
		eg.attack();
		eg.fly("고속비행");
		eg.bark("끼룩끼룩ㄲㄲ룩");
	}
	
	public void test7() {
		Animal tiger = new Tiger();
		Animal lion = new Lion();
		
		tiger.say();
		lion.say();
		
		Runnable _tiger = new Tiger();
		Runnable _lion = new Lion();
		_tiger.run();
		_lion.run();
		
		((Animal) _lion).say();
		
		Tiger rt = new Tiger();
		rt.say();
		rt.attack();
		rt.run();
		
		Barkable bt = new Tiger();
		Barkable bl = new Lion();
		bt.bark("우아앙ㅇ");
		bl.bark("크아앙ㅇ");
		
		BarkAction(new Tiger(), "우아앙ㅇ");
		BarkAction(new Lion(), "크아앙ㅇ");
		
		Barkable[] ba = new Barkable[3];
		ba[0] = new Tiger();
		ba[1] = new Lion();
		ba[2] = new Tiger();
		
		for(Barkable b : ba) {
			b.bark("끼엥에엑");
		}
		
	}

	public void BarkAction(Barkable ba, String sound) {
		ba.bark(sound);
	}
	
	public void test6() {
		Animal[] animals = new Animal[3];
		for(int i = 0; i < animals.length; i++) {
			animals[i] = generateAnimal();
			animals[i].say();
			animals[i].attack();
		}
	}
	
	/**
	 * 다형성과 override
	 * 
	 * 정적바인딩
	 * - 어떤 메소드를 호출할지 작성된 타입에 의해 결정
	 * 동적바인딩
	 * - 다운캐스팅없이 자식클래스의 오버라이드된 메소드를 호출
	 * - 오버라이드 + 다형성
	 */
	public void test5() {
		Animal tiger = new Tiger();
		Animal lion = new Lion();
		
		tiger.say();
		lion.say();
		
		// downcasting없이 Tiger#punch, Lion#kick 호출하기
		tiger.attack();
		lion.attack();
		
	}
	
	/**
	 * 리턴타입에서 다형성 활용하기
	 */
	public void test4() {
		Animal animal = generateAnimal();
		System.out.println(animal);
	}
	
	/**
	 * Tiger객체 또는 Lion객체를 생성
	 * @return
	 */
	public Animal generateAnimal() {
		return new Random().nextBoolean() ? 
					new Tiger() : 
						new Lion();
	}
	
	
	
	/**
	 * 매개변수부에 다형성 활용하기
	 */
	public void test3() {
		Tiger tiger = new Tiger();
		Lion lion = new Lion();
		
		attack(tiger);
		attack(lion);
	}
	
//	public void attack(Tiger tiger) {}
//	public void attack(Lion lion) {}
	
	public void attack(Animal animal) {
		if(animal instanceof Tiger) {
			((Tiger) animal).punch();			
		}
		else if(animal instanceof Lion) {
			((Lion) animal).kick();			
		}
	}
	
	/**
	 * 부모타입의 변수에 자식타입의 객체를 모두 담아 처리할 수 있다.
	 */
	public void test2() {
		Tiger tiger = new Tiger();
		Lion lion = new Lion();
		
		Animal[] animals = new Animal[3];
		animals[0] = new Tiger();
		animals[1] = new Lion();
		animals[2] = new Tiger();
		
		for(int i = 0; i < animals.length; i++) {
//			System.out.println(animals[i]);
			animals[i].say();
			
			// 객체 instanceof 클래스 : boolean
			// instanceof연산결과가 true라면, 해당클래스로 무조건 형변환할수 있다. (ClassCastException이 발생안함)
			if(animals[i] instanceof Tiger) {
				((Tiger) animals[i]).punch();
			}
			else if(animals[i] instanceof Lion) {
				((Lion) animals[i]).kick();
			}
		}
	}

	/**
	 * - upcasting : 자식타입를 부모타입으로 변환 (자동)
	 * - downcasting : 부모타입을 자식타입으로 변환 (명시적 형변환)
	 * 
	 * 자식객체가 부모타입의 변수에 대입되면, 부모타입의 멤버(필드/메소드)만 사용가능하다.
	 * 
	 */
	public void test1() {
		Tiger tiger = new Tiger();
		Animal animal1 = tiger;
		
		tiger.say();
		tiger.punch();
		
		animal1.say();
//		animal1.punch(); 
		
		// downcasting
		((Tiger) animal1).punch();
		Tiger anotherTiger = (Tiger) animal1;
		anotherTiger.say();
		anotherTiger.punch();
		
		
		Animal animal2 = new Lion();
		animal2.say();
		((Lion) animal2).kick();
		Lion anotherLion = (Lion) animal2;
		anotherLion.kick();
		
	}

}







