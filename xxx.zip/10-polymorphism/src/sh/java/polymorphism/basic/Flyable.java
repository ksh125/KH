package sh.java.polymorphism.basic;

public interface Flyable {

	void fly(String fly);
	
}
