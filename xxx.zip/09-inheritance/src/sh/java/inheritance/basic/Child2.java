package sh.java.inheritance.basic;

public class Child2 extends Parent {
	
}
