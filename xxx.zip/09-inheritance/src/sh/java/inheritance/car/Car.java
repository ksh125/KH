package sh.java.inheritance.car;

import java.util.Objects;

public class Car {

	private String name;
	private String color;
	private int doorCnt;
	
	public Car() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Car(String name, String color, int doorCnt) {
		super();
		this.name = name;
		this.color = color;
		this.doorCnt = doorCnt;
	}
	
	/**
	 * 복사생성자
	 * @param other
	 */
	public Car(Car other) {
		System.out.println("other = " + other);
		this.name = other.name;
		this.color = other.color;
		this.doorCnt = other.doorCnt;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public int getDoorCnt() {
		return doorCnt;
	}

	public void setDoorCnt(int doorCnt) {
		this.doorCnt = doorCnt;
	}
	
	@Override
	public String toString() {
		return "Car [name = " + name + ", color = " + color + ", doorCnt = " + doorCnt + "]";
	}
	
	/**
	 * 동등성비교 (원하는 컬럼값이 동일하다면 같은 객체로 간주한다.)
	 * - name:String
	 * - color:String
	 * - doorCnt:int
	 * 
	 * 자바약속 : equals비교결과 true라면, hashCode값이 같아야 한다.
	 * 			(equals에 사용된 필드값기준으로 hashCode를 재생성해야 한다.)
	 * - equals와 hashCode는 같이 override한다.(비교하는 필드가 동일)
	 */
	@Override
	public boolean equals(Object obj) {
		if(this == obj)
			return true;
		if(obj == null)
			return false;
		if(!(obj instanceof Car))
			return false;
		
		Car other = (Car) obj; // Car타입으로 강제형변환
		if(!this.name.equals(other.name))
			return false;
		if(!this.color.equals(other.color))
			return false;
		if(this.doorCnt != other.doorCnt)
			return false;
		
		return true;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(this.name, this.color, this.doorCnt);
	}
	
	/**
	 * Method Overriding
	 * - 상속받은 부모메서드를 재작성하는 것
	 * - 메소드시그니쳐(접근제한자, 리턴타입, 메소드명, 매개변수선언, 예외)이 모두 동일해야 한다.
	 *   - @Override 어노테이션을 통해 컴파일타임에 체크.
	 * - 접근제한자는 상속받은 것보다 더 개방할 수 있다.
	 * 	 - default < protected < public
	 * - private/final 메소드는 override가 불가능하다.
	 * - 선언부 예외를 일부만 던지거나, 제거할 수 있다.
	 * - 공변반환타입(1.5) : 부모메소드의 반환타입를 자식클래스타입으로 변환 가능
	 * 
	 * 복사생성자를 통한 clone처리
	 */
	@Override
	public Car clone() {
		return new Car(this);
	}
	
	
	
}
