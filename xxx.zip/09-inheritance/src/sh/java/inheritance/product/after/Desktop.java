package sh.java.inheritance.product.after;

import java.util.Arrays;

/**
 * 상속
 * - 부모클래스가 가진 멤버(필드/메소드)를 자식클래스에 선언없이 사용할수 있도록 한다.
 * - 자식클래스의 공통된 코드(중복된 코드)를 부모클래스에 효율적을 관리할 수 있다.
 * 
 * 특징
 * - 부모의 필드/메소드를 자식클래스에서 선언없이 접근
 * - 부모의 private멤버는 상속을 받았으나 직접 접근이 안됨.
 *   - public메소드를 통해 제어
 *   - super 부모생성자를 호출해서 부모클래스안에서 값설정함.
 * - 모든 클래스는 Object클래스의 후손
 * 	 - Object의 메소드를 모든 클래스에서 사용가능.
 *   - toString(), hashCode(), equals()
 *   - extends 부모클래스 선언이 없다면, extends Object가 생략된 형태 
 * - 부모클래스의 생성자/초기화블럭은 상속이 안된다.
 * 	 - 자식클래스에서 별도로 작성해야 함.
 * - 물려받은 메소드를 자식클래스에 따라 Override할수 있다.
 *   - 단, 메소드시그니쳐가 동일해야한다.
 *   
 *   
 * 모든 생성자는 첫줄에 this() 또는 super() 호출한다.
 * - 아무것도 적혀있지 않다면 super()가 생략된 것이다.
 *
 */
public class Desktop extends Product {
	
	private String os;
	private String[] hardwares;
	
	public Desktop() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * 물려받은 private필드에 직접접근할 수 없다.
	 * 
	 * 
	 * @param productCode
	 * @param productName
	 * @param brand
	 * @param price
	 * @param os
	 * @param hardwares
	 */
	public Desktop(String productCode, String productName, String brand, int price, String os, String[] hardwares) {
//		this.productCode = productCode;
//		this.productName = productName;
//		this.brand = brand;
//		this.price = price;
		
		// 부모생성자호출을 통해 private필드값 설정
		// super() 호출도 생성자맨첫줄에 단한번 사용가능
		super(productCode, productName, brand, price);
		
		this.os = os;
		this.hardwares = hardwares;
	}

	public String getOs() {
		return os;
	}

	public void setOs(String os) {
		this.os = os;
	}

	public String[] getHardwares() {
		return hardwares;
	}

	public void setHardwares(String[] hardwares) {
		this.hardwares = hardwares;
	}
	
	public String desktopInfo() {
		return productInfo() + ", os = " + this.os + ", hardwares = " + Arrays.toString(hardwares); 
	}

}
