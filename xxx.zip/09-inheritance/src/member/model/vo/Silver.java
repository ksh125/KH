package member.model.vo;

import member.model.vo.other.Member;

public class Silver extends Member{
	
	public Silver() {}
	
	public Silver(String name, String grade, int point) {
		super(name, grade, point);
	}
	
	@Override
	public double getEjapoint(){ 
		return super.getPoint() * 0.02;
	}
}