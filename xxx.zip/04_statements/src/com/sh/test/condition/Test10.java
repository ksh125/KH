package com.sh.test.condition;

import java.util.Scanner;

/**
 * <pre>
 * 점수를 입력 받고 등급을 출력하는 프로그램을 작성하시오.
 * 
 * 100~90은 수,
 * 89~80는 우,
 * 79~70은 미,
 * 69~60은 양,
 * 나머지는 가로 처리하세요.
 * 
 * 예 ) 95점은  수입니다.
 * </pre>
 */
public class Test10 {

	public static void main(String[] args) {
		Test10 t = new Test10();
		t.test();
	}

	private void test() {
		Scanner sc = new Scanner(System.in);
		System.out.print("점수를 입력하세요 => ");
		int mark = sc.nextInt();

		String grade = "";

		if (mark <= 100 && mark >= 90) {
			grade = "수";
		} else if (mark < 90 && mark >= 80) {
			grade = "우";
		} else if (mark < 80 && mark >= 70) {
			grade = "미";
		} else if (mark < 70 && mark >= 60) {
			grade = "양";
		} else {
			grade = "가";
		}

		System.out.println(mark + "점은 " + grade + "입니다.");
	}

}
