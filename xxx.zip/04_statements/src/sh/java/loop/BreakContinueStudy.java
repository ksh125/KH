package sh.java.loop;

public class BreakContinueStudy {

	public static void main(String[] args) {
		BreakContinueStudy study = new BreakContinueStudy();
//		study.test1();
//		study.test2();
		study.test3();
	}
	
	/**
	 * 1 ~ 100사이의 홀수만 출력 
	 * 1 ~ 100사이의 짝수만 출력
	 */
	public void test3() {
		// 홀수 for (짝수인 경우 continue)
		for(int i = 1; i <= 100; i++) {
			if(i % 2 == 0)
				continue;
			System.out.print(i + " ");
		}
		System.out.println();
		
		// 홀수 while (짝수인 경우 continue)
		int i = 0;
		while(i++ < 100) {
			if(i % 2 ==  0) continue;
			System.out.print(i + " ");
		}
		
		System.out.println();
		// 짝수 for (홀수인 경우 continue)
		for(int j = 1; j <= 100; j++) {
			if(j % 2 != 0)
				continue;
			System.out.print(j + " ");
		}
		System.out.println();
		
		// 짝수 while (홀수인 경우 continue)
		int j = 0;
		while(j++ <100) {
			if(j % 2 != 0)
				continue;
			System.out.print(j + " ");
		}
		
	}
	
	/**
	 * continue
	 * - 반복문 실행시 continue를 만나면, 이하 코드를 실행하지 않고 반복문의 처음을 돌아간다.
	 * - for문의 증감식으로 이동
	 * - while문의 조건식으로 이동 (continue하위에 증감식이 있어서는 안된다.)
	 */
	public void test2() {
		// 짝수만 출력
//		for(int i = 1; i <= 5; i++) {
//			if(i % 2 != 0)
//				continue;
//			System.out.println(i);
//		}
		
		int i = 0;
		while(i < 5) {
			i++;
			if(i % 2 != 0)
				continue;
			System.out.println(i);
		}
		
	}
	
	/**
	 * break 
	 * - 반복문을 즉시 중단하고 탈출!
	 */
	public void test1() {
		int i = 0;
//		while(true) {
//			if(i > 100) {
//				break;
//			}
//			System.out.println(i);
//			i++;
//		}
		
		int sum = 0;
		i = 1;
		while(true) {
			if(i > 10)
				break;
			sum += i++;
		}
		
		System.out.println("1 ~ 10까지의 합은 " + sum + "입니다.");
		
	}
}
