package test.controller;

import java.util.Scanner;

public class Test4 {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("첫번째 수를 입력하세요 : ");
		int a = sc.nextInt();
		System.out.print("두번째 수를 입력하세요 : ");
		int b = sc.nextInt();
		
		if(a < 10 && b < 10) {
			System.out.printf("합 : %d\n", (a + b));
			if(a > b) {
				System.out.printf("차 : %d\n", (a - b));
			} else {
				System.out.printf("차 : %d\n", (b - a));
			}
			System.out.printf("곱 : %d\n", (a * b));
			if(a > b) {
				System.out.printf("나누기 : %d\n", (a / b));
			} else {
				System.out.printf("나누기 : %d\n", (b / a));
			}
		}
		
	}
	
}
