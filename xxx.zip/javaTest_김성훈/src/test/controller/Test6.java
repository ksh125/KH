package test.controller;

import java.util.Scanner;

public class Test6 {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("원하시는 숫자를 입력하세요 : ");
		
		
	}
}
