package test.controller;

import java.util.Scanner;

public class Test5 {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("첫번째 수 수를 입력하세요 : ");
		int a = sc.nextInt();
		System.out.println("두번째 수 수를 입력하세요 : ");
		int b = sc.nextInt();
		
		if(a < 10 && b < 10) {
			if((a * b) < 10) {
				System.out.println("한자리 수 입니다");
			} else {
				System.out.println("두자리 수 입니다");
			}
		}
		
	}

}
